-- Piotr Radwan 372185
import Mojzbior

main = do
  print $ iloczyn [1,2,3] [3,4,5]
